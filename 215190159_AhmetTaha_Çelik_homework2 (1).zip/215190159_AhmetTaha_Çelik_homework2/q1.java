import java.util.*;
import java.io.*;

public class q1 {

    private LinkedList<String> row; //entire text
    private ArrayList<String> argument;
    private int index;

    private q1() {
        this.index = 0;
        this.row = new LinkedList<>();
        this.argument = new ArrayList<>();
    }

    private void add(String line) {
        this.row.add(this.index, line);
        this.index++;
    }

    private void delete() {
        this.index--;
        this.row.remove(this.index);
    }

    private void delete(int i) {
        this.row.remove(i);
        if (this.index >= i)
            this.index--;
    }

    private void delete(int i, int j) {
        for (; i <= j; i++) {
            if (this.index >= i)
                this.index--;
            this.row.remove(i);
        }
    }

    private void list() {
        for (int i = 0; i < this.row.size(); i++)
            this.argument.add(i + 1 + ">" + this.row.get(i));
    }

    private void save(String filename) throws IOException {
        FileWriter out = new FileWriter(filename);
        for (String i : this.row) out.write(i + '\n');
        out.close();
    }

    private void exit() throws IOException {
        FileWriter out = new FileWriter("OutputFile.txt");
        for (String i : this.argument) out.write(i + '\n');
        out.close();
    }

    private int getArgs(String input, int i) {
        return Integer.parseInt(input.split(" ")[i]) - 1;
    }

    private void execute(String input) throws IOException {
        this.argument.add(this.index + 1 + ">" + input);

        if (input.equals("I"))
            this.index--;

        else if (input.matches("I\\s[0-9]")) //Since we want to get the only nominations value from each element.
            this.index = this.getArgs(input, 1);

        else if (input.equals("D")) //delete the lastly added
            this.delete();

        else if (input.matches("D\\s[0-9]+\\s[0-9]+")) // D matches the character, \\ matches the character and s matches the character 
            this.delete(this.getArgs(input, 1), this.getArgs(input, 2));

        else if (input.matches("D\\s[0-9]+")) 
            this.delete(this.getArgs(input, 1));

        else if (input.equals("L")) //to make it list
            this.list();

        else if (input.equals("A")) //to append the value to the index
            this.index = this.row.size();

        else if (input.startsWith("S ")) //write it to the file
            this.save(input.split(" ")[1]);

        else if (input.equals("E")) //to exit before than save the file
            this.exit();

        else
            this.add(input);
    }

    private void read() throws IOException {
        Scanner in = new Scanner(new FileReader("InputFile.txt"));
        while (in.hasNextLine()) {
            this.execute(in.nextLine());
        }
        in.close();
    }

    public static void main(String[] args) throws IOException {
        q1 t = new q1();
        t.read();
    }

}